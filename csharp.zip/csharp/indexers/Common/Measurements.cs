﻿namespace IndexersSamples.Common
{
    public class Measurements
    {
        public int HiTemp { get; set; }
        public int LoTemp { get; set; }

        public double AirPressure { get; set; }
    }
}
